#!/bin/bash

# Enhanced Create Account Script with uppercase text
# Version: 2.0

DOMAIN_FILE="/etc/AutoScriptX/domain"
PORT_INFO="/etc/AutoScriptX/port-info.json"

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Function to display header
display_header() {
  clear
  echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}║${WHITE}                            🛠️  CREATE SSH ACCOUNT                            ${CYAN}║${NC}"
  echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to get user input
get_user_input() {
  echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${YELLOW}║${WHITE}                           ACCOUNT INFORMATION                               ${YELLOW}║${NC}"
  echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
  
  echo -ne "${PURPLE}👤 ENTER USERNAME: ${WHITE}"
  read -r username
  echo -ne "${PURPLE}🔑 ENTER PASSWORD: ${WHITE}"
  read -r password
  echo -ne "${PURPLE}📅 EXPIRY DAYS: ${WHITE}"
  read -r expire_days
  echo ""
}

# Function to create account
create_account() {
  public_ip=$(curl -s ifconfig.me)
  domain=$(cat "$DOMAIN_FILE" 2>/dev/null || echo "NOT SET")
  expire_date=$(date -d "$expire_days days" +"%Y-%m-%d")
  
  # Create user account
  useradd -e "$expire_date" -s /bin/false -M "$username"
  echo -e "$password\n$password" | passwd "$username" &>/dev/null
  expire_date_str=$(chage -l "$username" | grep "Account expires" | cut -d: -f2 | xargs)
}

# Function to display account details
display_account_details() {
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║${WHITE}                          ✅ ACCOUNT CREATED SUCCESSFULLY                     ${GREEN}║${NC}"
  echo -e "${GREEN}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}║${WHITE}  👤 USERNAME         : ${YELLOW}$username${GREEN}║${NC}"
  echo -e "${GREEN}║${WHITE}  🔑 PASSWORD         : ${YELLOW}$password${GREEN}║${NC}"
  echo -e "${GREEN}║${WHITE}  📅 EXPIRES ON       : ${YELLOW}$expire_date_str${GREEN}║${NC}"
  echo -e "${GREEN}║${WHITE}  🌐 PUBLIC IP        : ${YELLOW}$public_ip${GREEN}║${NC}"
  echo -e "${GREEN}║${WHITE}  📡 HOST DOMAIN      : ${YELLOW}$domain${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to display port information
display_port_info() {
  echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${BLUE}║${WHITE}                              📦 PORT INFORMATION                            ${BLUE}║${NC}"
  echo -e "${BLUE}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${BLUE}║                                                                              ║${NC}"
  echo -e "${BLUE}║${WHITE}  🔌 SSH WEBSOCKET    : ${CYAN}80${BLUE}║${NC}"
  echo -e "${BLUE}║${WHITE}  🔐 SSH SSL WS       : ${CYAN}443${BLUE}║${NC}"
  echo -e "${BLUE}║${WHITE}  🛡️  SSL/TLS          : ${CYAN}443${BLUE}║${NC}"
  echo -e "${BLUE}║${WHITE}  🦑 SQUID PROXY      : ${CYAN}8080${BLUE}║${NC}"
  echo -e "${BLUE}║${WHITE}  📡 UDP GATEWAY      : ${CYAN}7200, 7300${BLUE}║${NC}"
  echo -e "${BLUE}║                                                                              ║${NC}"
  echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to display payloads
display_payloads() {
  echo -e "${PURPLE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${PURPLE}║${WHITE}                              🧪 CONNECTION PAYLOADS                        ${PURPLE}║${NC}"
  echo -e "${PURPLE}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${PURPLE}║                                                                              ║${NC}"
  echo -e "${PURPLE}║${WHITE}  WSS PAYLOAD (SECURE):                                                   ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  GET WSS://EXAMPLE.COM HTTP/1.1[CRLF]                                    ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  HOST: $domain[CRLF]                                                      ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  UPGRADE: WEBSOCKET[CRLF][CRLF]                                          ${PURPLE}║${NC}"
  echo -e "${PURPLE}║                                                                              ║${NC}"
  echo -e "${PURPLE}║${WHITE}  WS PAYLOAD (STANDARD):                                                  ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  GET / HTTP/1.1[CRLF]                                                    ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  HOST: $domain[CRLF]                                                      ${PURPLE}║${NC}"
  echo -e "${PURPLE}║${CYAN}  UPGRADE: WEBSOCKET[CRLF][CRLF]                                          ${PURPLE}║${NC}"
  echo -e "${PURPLE}║                                                                              ║${NC}"
  echo -e "${PURPLE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to ask for return to menu
ask_return_menu() {
  echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${YELLOW}║${WHITE}                            RETURN TO MAIN MENU?                            ${YELLOW}║${NC}"
  echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo -n -e "${WHITE}PRESS [Y/N]: ${NC}"
  read -r choice
  
  if [[ $choice =~ ^[Yy]$ ]]; then
    menu
  else
    echo -e "${GREEN}THANK YOU FOR USING AUTOSCRIPTX!${NC}"
    exit 0
  fi
}

# Main execution
display_header
get_user_input
create_account
display_account_details
display_port_info
display_payloads
ask_return_menu

