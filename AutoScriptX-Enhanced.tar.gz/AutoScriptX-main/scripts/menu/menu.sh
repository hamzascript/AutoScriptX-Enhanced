#!/bin/bash

# Function to display error messages
display_error() {
  gum style --foreground "#ff5555" --border double --margin "1 2" --padding "1 2" "🚫 $1"
}

# Check for root privileges
check_root() {
  if [ "$(id -u)" -ne 0 ]; then
    display_error "Please run this script as root."
    exit 1
  fi
}

# Function to get system information
get_system_info() {
  os_name=$(hostnamectl | grep 'Operating System' | cut -d ':' -f2- | xargs)
  uptime=$(uptime -p | cut -d " " -f 2-10)
  public_ip=$(curl -s ifconfig.me)
  vps_domain=$(cat /etc/AutoScriptX/domain 2>/dev/null || echo "Not Set")
  used_ram=$(free -m | awk 'NR==2 {print $3}')
  total_ram=$(free -m | awk 'NR==2 {print $2}')
}

# Function to display main menu header
display_header() {
  clear
  gum format --theme dracula <<EOF

# 🚀 AUTOSCRIPTX - VPS MANAGER

- **OS**         : $os_name  
- **UPTIME**     : $uptime  
- **PUBLIC IP**  : $public_ip  
- **DOMAIN**     : $vps_domain  

# 🧠 RAM INFORMATION

- **USED RAM**   : ${used_ram} MB  
- **TOTAL RAM**  : ${total_ram} MB  

# 📋 MAIN MENU
EOF
}

# Main script execution
check_root
get_system_info
display_header

opt=$(gum choose --limit=1 --header "  CHOOSE AN OPTION" \
  "1. CREATE ACCOUNT" \
  "2. DELETE ACCOUNT" \
  "3. RENEW ACCOUNT" \
  "4. LOCK/UNLOCK ACCOUNT" \
  "5. EDIT BANNER" \
  "6. EDIT 101 RESPONSE" \
  "7. CHANGE DOMAIN" \
  "8. MANAGE SERVICES" \
  "9. SYSTEM INFO" \
  "X. EXIT")

clear
case "$opt" in
  "1. CREATE ACCOUNT") create-account ;;
  "2. DELETE ACCOUNT") delete-account ;;
  "3. RENEW ACCOUNT") renew-account ;;
  "4. LOCK/UNLOCK ACCOUNT") lock-unlock ;;
  "5. EDIT BANNER") edit-banner ;;
  "6. EDIT 101 RESPONSE") edit-response ;;
  "7. CHANGE DOMAIN") change-domain ;;
  "8. MANAGE SERVICES") manage-services ;;
  "9. SYSTEM INFO") system-info ;;
  "X. EXIT") exit ;;
esac


