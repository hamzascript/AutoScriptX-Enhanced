#!/bin/bash

# AutoScriptX Enhanced Installation Script
# Version: 2.0
# Enhanced with better UI and improved functionality

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Function to display animated installation header
display_install_header() {
  clear
  echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}║                                                                              ║${NC}"
  echo -e "${CYAN}║${WHITE}    ██████╗ ██╗   ██╗████████╗ ██████╗ ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}   ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}   ███████║██║   ██║   ██║   ██║   ██║███████╗██║     ██████╔╝██║██████╔╝   ██║   ${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}   ██╔══██║██║   ██║   ██║   ██║   ██║╚════██║██║     ██╔══██╗██║██╔═══╝    ██║   ${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}   ██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████║╚██████╗██║  ██║██║██║        ██║   ${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}   ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝   ${CYAN}║${NC}"
  echo -e "${CYAN}║                                                                              ║${NC}"
  echo -e "${CYAN}║${YELLOW}                        🚀 ENHANCED INSTALLATION SCRIPT 🚀                   ${CYAN}║${NC}"
  echo -e "${CYAN}║${WHITE}                              VERSION 2.0 - ENHANCED                          ${CYAN}║${NC}"
  echo -e "${CYAN}║                                                                              ║${NC}"
  echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to display progress
display_progress() {
  echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${BLUE}║${WHITE}                              INSTALLATION PROGRESS                          ${BLUE}║${NC}"
  echo -e "${BLUE}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${BLUE}║                                                                              ║${NC}"
  echo -e "${BLUE}║${WHITE}  🔄 $1${BLUE}║${NC}"
  echo -e "${BLUE}║                                                                              ║${NC}"
  echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to display success message
display_success() {
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║${WHITE}                              ✅ SUCCESS                                     ${GREEN}║${NC}"
  echo -e "${GREEN}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}║${WHITE}  $1${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# Function to check root privileges
check_root() {
  if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║${WHITE}                                    ERROR                                     ${RED}║${NC}"
    echo -e "${RED}║${WHITE}                        PLEASE RUN THIS SCRIPT AS ROOT!                      ${RED}║${NC}"
    echo -e "${RED}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    exit 1
  fi
}

# Function to create directories
create_directories() {
  display_progress "CREATING SYSTEM DIRECTORIES..."
  mkdir -p /etc/AutoScriptX
  mkdir -p /usr/local/bin/AutoScriptX
  mkdir -p /var/log/AutoScriptX
  display_success "DIRECTORIES CREATED SUCCESSFULLY"
  sleep 1
}

# Function to copy files
copy_files() {
  display_progress "COPYING ENHANCED SCRIPTS..."
  
  # Copy enhanced menu
  cp scripts/menu/menu_enhanced.sh /usr/local/bin/AutoScriptX/menu
  chmod +x /usr/local/bin/AutoScriptX/menu
  
  # Copy enhanced create account script
  cp scripts/ssh/create-account-enhanced.sh /usr/local/bin/AutoScriptX/create-account
  chmod +x /usr/local/bin/AutoScriptX/create-account
  
  # Copy other scripts (you can enhance these too)
  cp scripts/ssh/*.sh /usr/local/bin/AutoScriptX/
  cp scripts/system/*.sh /usr/local/bin/AutoScriptX/
  
  # Make all scripts executable
  chmod +x /usr/local/bin/AutoScriptX/*
  
  display_success "ENHANCED SCRIPTS COPIED SUCCESSFULLY"
  sleep 1
}

# Function to create symbolic links
create_links() {
  display_progress "CREATING SYSTEM LINKS..."
  
  # Create symbolic links for easy access
  ln -sf /usr/local/bin/AutoScriptX/menu /usr/local/bin/menu
  ln -sf /usr/local/bin/AutoScriptX/create-account /usr/local/bin/create-account
  ln -sf /usr/local/bin/AutoScriptX/delete-account.sh /usr/local/bin/delete-account
  ln -sf /usr/local/bin/AutoScriptX/renew-account.sh /usr/local/bin/renew-account
  ln -sf /usr/local/bin/AutoScriptX/lock-unlock.sh /usr/local/bin/lock-unlock
  ln -sf /usr/local/bin/AutoScriptX/edit-banner.sh /usr/local/bin/edit-banner
  ln -sf /usr/local/bin/AutoScriptX/edit-response.sh /usr/local/bin/edit-response
  ln -sf /usr/local/bin/AutoScriptX/change-domain.sh /usr/local/bin/change-domain
  ln -sf /usr/local/bin/AutoScriptX/manage-services.sh /usr/local/bin/manage-services
  ln -sf /usr/local/bin/AutoScriptX/system-info.sh /usr/local/bin/system-info
  
  display_success "SYSTEM LINKS CREATED SUCCESSFULLY"
  sleep 1
}

# Function to set default domain
set_default_domain() {
  display_progress "SETTING DEFAULT CONFIGURATION..."
  
  # Get public IP
  public_ip=$(curl -s ifconfig.me)
  echo "$public_ip" > /etc/AutoScriptX/domain
  
  # Create default port info
  cat > /etc/AutoScriptX/port-info.json << EOF
{
  "ssh_ws": 80,
  "ssh_ssl_ws": 443,
  "ssl_tls": 443,
  "squid": 8080,
  "udpgw": [7200, 7300]
}
EOF
  
  display_success "DEFAULT CONFIGURATION SET"
  sleep 1
}

# Function to display completion message
display_completion() {
  clear
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}║${WHITE}                        🎉 INSTALLATION COMPLETED! 🎉                        ${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}║${WHITE}                      AUTOSCRIPTX ENHANCED VERSION 2.0                      ${GREEN}║${NC}"
  echo -e "${GREEN}║${WHITE}                         HAS BEEN INSTALLED SUCCESSFULLY                     ${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}╠══════════════════════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${GREEN}║${WHITE}                              HOW TO USE:                                   ${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}║${YELLOW}  • TYPE 'MENU' TO ACCESS THE MAIN MENU                                   ${GREEN}║${NC}"
  echo -e "${GREEN}║${YELLOW}  • ALL COMMANDS ARE NOW AVAILABLE SYSTEM-WIDE                            ${GREEN}║${NC}"
  echo -e "${GREEN}║${YELLOW}  • ENHANCED UI WITH BETTER COLORS AND LAYOUT                             ${GREEN}║${NC}"
  echo -e "${GREEN}║${YELLOW}  • UPPERCASE TEXT FOR BETTER READABILITY                                 ${GREEN}║${NC}"
  echo -e "${GREEN}║                                                                              ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "${CYAN}PRESS ANY KEY TO START THE ENHANCED MENU...${NC}"
  read -n 1
  menu
}

# Main installation process
main() {
  display_install_header
  check_root
  create_directories
  copy_files
  create_links
  set_default_domain
  display_completion
}

# Start installation
main

